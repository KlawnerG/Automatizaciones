// Información del restaurante
const nombreNegocio = 'pepito 2';
const saludo = 'jjkhjk';
const despedida = 'kjkl';
const contacto = '24121';

// Menú
const menu = [
 {
 nombre: 'hamburguesa',
 descripcion: 'rtsfg',
 precio: 18.300
 },
];
